import App from './App';

export function Component() {
  return <App />;
}

export default Component;